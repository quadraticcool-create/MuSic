# MyMusic

A dark, lime-accented offline Android music player built with Kotlin, Jetpack Compose and Media3.

## Features included
- Reads music indexed by Android MediaStore
- Plays local audio with Media3 ExoPlayer
- Library list, search, liked songs, now-playing screen and mini-player
- Previous/next, seek, shuffle, play/pause
- GitHub Actions workflow to build a debug APK

## Build with GitHub Actions
1. Create a private GitHub repository named `MyMusic`.
2. Upload the contents of this folder to the repository root (including `.github`).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build MyMusic APK** (or push a commit to `main`).
5. Open the successful workflow run and download the `MyMusic-debug-apk` artifact.
6. Unzip the artifact to get `app-debug.apk`.

## Build locally
Requires JDK 17 and Gradle 8.9 or compatible:
`gradle :app:assembleDebug`

## Notes
- The app only reads local audio; it does not stream or download music.
- Android will ask for audio permission on first launch.
- Liked songs are currently kept in app memory and reset when the process is killed.
- Playlist creation and persistent favourites are not implemented in this starter version.
- A Gradle wrapper is not included; GitHub Actions uses the installed Gradle command.
