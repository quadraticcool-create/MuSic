package com.sanskar.mymusic

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF08080D)
private val SurfaceDark = Color(0xFF171720)
private val SurfaceLight = Color(0xFF22222D)
private val Lime = Color(0xFFD7F45B)
private val Muted = Color(0xFF92929F)
private val White = Color(0xFFF5F5F7)

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uri: Uri,
    val artUri: Uri?
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 8, 13)
        window.navigationBarColor = android.graphics.Color.rgb(8, 8, 13)
        setContent { MyMusicApp() }
    }
}

@Composable
fun MyMusicApp() {
    val context = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    var songs by remember { mutableStateOf(emptyList<Song>()) }
    var selectedSong by remember { mutableStateOf<Song?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var tab by remember { mutableStateOf("All") }
    var screen by remember { mutableStateOf("library") }
    var favorites by remember { mutableStateOf(setOf<Long>()) }
    var permissionGranted by remember {
        mutableStateOf(hasAudioPermission(context))
    }
    var search by remember { mutableStateOf("") }
    var shuffle by remember { mutableStateOf(false) }

    fun loadSongs() {
        songs = querySongs(context)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
        if (granted) loadSongs()
    }

    LaunchedEffect(Unit) {
        if (permissionGranted) loadSongs()
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val index = player.currentMediaItemIndex
                selectedSong = songs.getOrNull(index)
                duration = player.duration.coerceAtLeast(0L)
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(isPlaying, selectedSong) {
        while (true) {
            currentPosition = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.coerceAtLeast(0L)
            delay(500)
        }
    }

    fun playSong(song: Song) {
        val index = songs.indexOf(song)
        if (index >= 0) {
            selectedSong = song
            player.setMediaItems(songs.map { MediaItem.fromUri(it.uri) }, index, 0L)
            player.prepare()
            player.play()
            screen = "player"
        }
    }

    val visibleSongs = when (tab) {
        "Liked Songs" -> songs.filter { favorites.contains(it.id) }
        else -> songs
    }.filter {
        it.title.contains(search, true) || it.artist.contains(search, true)
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = SurfaceDark,
            primary = Lime,
            onPrimary = Bg,
            onBackground = White,
            onSurface = White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize()) {
                AnimatedContent(targetState = screen, label = "screen") { target ->
                    if (target == "player" && selectedSong != null) {
                        NowPlayingScreen(
                            song = selectedSong!!,
                            isPlaying = isPlaying,
                            position = currentPosition,
                            duration = duration,
                            isFavorite = favorites.contains(selectedSong!!.id),
                            shuffle = shuffle,
                            onBack = { screen = "library" },
                            onFavorite = {
                                favorites = if (favorites.contains(selectedSong!!.id))
                                    favorites - selectedSong!!.id else favorites + selectedSong!!.id
                            },
                            onPlayPause = { if (player.isPlaying) player.pause() else player.play() },
                            onNext = { player.seekToNextMediaItem() },
                            onPrevious = { player.seekToPreviousMediaItem() },
                            onShuffle = {
                                shuffle = !shuffle
                                player.shuffleModeEnabled = shuffle
                            },
                            onSeek = { player.seekTo(it) }
                        )
                    } else {
                        LibraryScreen(
                            songs = visibleSongs,
                            allCount = songs.size,
                            likedCount = favorites.size,
                            selectedTab = tab,
                            search = search,
                            currentSong = selectedSong,
                            isPlaying = isPlaying,
                            onTab = { tab = it },
                            onSearch = { search = it },
                            onPlay = { playSong(it) },
                            onOpenPlayer = { if (selectedSong != null) screen = "player" },
                            onPlayPause = { if (player.isPlaying) player.pause() else player.play() },
                            permissionGranted = permissionGranted,
                            onRequestPermission = {
                                val permission = if (Build.VERSION.SDK_INT >= 33)
                                    Manifest.permission.READ_MEDIA_AUDIO
                                else Manifest.permission.READ_EXTERNAL_STORAGE
                                permissionLauncher.launch(permission)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryScreen(
    songs: List<Song>,
    allCount: Int,
    likedCount: Int,
    selectedTab: String,
    search: String,
    currentSong: Song?,
    isPlaying: Boolean,
    onTab: (String) -> Unit,
    onSearch: (String) -> Unit,
    onPlay: (Song) -> Unit,
    onOpenPlayer: () -> Unit,
    onPlayPause: () -> Unit,
    permissionGranted: Boolean,
    onRequestPermission: () -> Unit
) {
    Box(Modifier.fillMaxSize()) {
      Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).padding(bottom = if (currentSong != null) 82.dp else 0.dp)) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircleIcon(Icons.Default.ArrowBack, "Back", {}) 
            Spacer(Modifier.weight(1f))
            Text("My Music", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            CircleIcon(Icons.Default.MoreHoriz, "More", {})
        }
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Playlists", "Liked Songs", "Downloaded").forEach { item ->
                val active = selectedTab == item
                Box(
                    Modifier.clip(CircleShape)
                        .background(if (active) Lime else SurfaceDark)
                        .clickable { onTab(item) }
                        .padding(horizontal = 17.dp, vertical = 11.dp)
                ) {
                    Text(item, color = if (active) Bg else Muted, fontSize = 13.sp,
                        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = search,
            onValueChange = onSearch,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            placeholder = { Text("Search your music", color = Muted, fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = SurfaceLight,
                focusedBorderColor = Lime,
                unfocusedContainerColor = SurfaceDark,
                focusedContainerColor = SurfaceDark
            )
        )
        Spacer(Modifier.height(20.dp))

        if (!permissionGranted) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.LibraryMusic, null, tint = Lime, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Let MyMusic find your songs", color = White, fontWeight = FontWeight.SemiBold)
                    Text("Your audio files stay on your device.", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onRequestPermission, colors = ButtonDefaults.buttonColors(containerColor = Lime)) {
                        Text("Allow music access", color = Bg)
                    }
                }
            }
        } else if (selectedTab == "Playlists" || selectedTab == "Downloaded") {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (selectedTab == "Playlists") "Playlist creation is coming next." else "Showing music stored on this device.",
                    color = Muted
                )
            }
        } else if (songs.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.MusicOff, null, tint = Muted, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("No music found", color = White, fontWeight = FontWeight.SemiBold)
                    Text("Add audio files to your phone and reopen MyMusic.", color = Muted, fontSize = 12.sp)
                }
            }
        } else if (songs.isEmpty()) {
            Text("No songs in this section.", color = Muted)
        } else {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(if (selectedTab == "Liked Songs") "Liked Songs" else "Your library",
                    color = White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                Spacer(Modifier.weight(1f))
                Text("${songs.size} songs", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = if (currentSong != null) 100.dp else 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(songs, key = { _, song -> song.id }) { _, song ->
                    SongRow(song = song, onClick = { onPlay(song) })
                }
            }
        }
      }
      if (currentSong != null) {
        MiniPlayer(
            song = currentSong,
            isPlaying = isPlaying,
            onClick = onOpenPlayer,
            onPlayPause = onPlayPause,
            modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 16.dp, vertical = 8.dp)
        )
      }
    }
}

@Composable
private fun SongRow(song: Song, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumArt(song.artUri, song.title, Modifier.size(66.dp))
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text("${song.artist}  •  ${formatDuration(song.duration)}", color = Muted, fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        CircleIcon(Icons.Default.PlayArrow, "Play ${song.title}", onClick)
    }
}

@Composable
private fun NowPlayingScreen(
    song: Song,
    isPlaying: Boolean,
    position: Long,
    duration: Long,
    isFavorite: Boolean,
    shuffle: Boolean,
    onBack: () -> Unit,
    onFavorite: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onShuffle: () -> Unit,
    onSeek: (Long) -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            CircleIcon(Icons.Default.ArrowBack, "Back", onBack)
            Spacer(Modifier.weight(1f))
            Text("Now Playing", color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            CircleIcon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                "Favorite", onFavorite, tint = if (isFavorite) Lime else White)
        }
        Spacer(Modifier.height(36.dp))
        AlbumArt(song.artUri, song.title,
            Modifier.fillMaxWidth().aspectRatio(1f).clip(CircleShape))
        Spacer(Modifier.height(28.dp))
        Text(song.title, color = White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(8.dp))
        Text(song.artist, color = Muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.weight(1f))
        Slider(
            value = if (duration > 0) position.coerceIn(0L, duration).toFloat() else 0f,
            onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()),
            colors = SliderDefaults.colors(
                thumbColor = Lime,
                activeTrackColor = Lime,
                inactiveTrackColor = SurfaceLight
            )
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatDuration(position), color = Muted, fontSize = 11.sp)
            Text("-${formatDuration((duration - position).coerceAtLeast(0L))}", color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(24.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onShuffle) {
                Icon(Icons.Default.Shuffle, null, tint = if (shuffle) Lime else Muted)
            }
            IconButton(onClick = onPrevious, modifier = Modifier.size(54.dp).background(SurfaceDark, CircleShape)) {
                Icon(Icons.Default.SkipPrevious, null, tint = White, modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = onPlayPause, modifier = Modifier.size(72.dp).background(Lime, CircleShape)) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null,
                    tint = Bg, modifier = Modifier.size(38.dp))
            }
            IconButton(onClick = onNext, modifier = Modifier.size(54.dp).background(SurfaceDark, CircleShape)) {
                Icon(Icons.Default.SkipNext, null, tint = White, modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = { /* queue screen can be added later */ }) {
                Icon(Icons.Default.QueueMusic, null, tint = Muted)
            }
        }
        Spacer(Modifier.height(38.dp))
    }
}

@Composable
private fun MiniPlayer(
    song: Song,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onPlayPause: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(SurfaceLight).clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumArt(song.artUri, song.title, Modifier.size(46.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onPlayPause) {
            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Lime)
        }
    }
}

@Composable
private fun AlbumArt(uri: Uri?, title: String, modifier: Modifier = Modifier) {
    if (uri != null) {
        AsyncImage(
            model = uri,
            contentDescription = "$title album artwork",
            modifier = modifier.clip(RoundedCornerShape(16.dp)),
            contentScale = ContentScale.Crop
        )
    } else {
        Box(
            modifier.clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF45515A), Color(0xFF1A1B27)))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.MusicNote, null, tint = Lime, modifier = Modifier.size(32.dp))
        }
    }
}

@Composable
private fun CircleIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit,
    tint: Color = White
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier.size(42.dp).background(SurfaceDark, CircleShape)
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(21.dp))
    }
}

private fun hasAudioPermission(context: android.content.Context): Boolean {
    val permission = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}

private fun querySongs(context: android.content.Context): List<Song> {
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.ALBUM_ID
    )
    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
    val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
    val result = mutableListOf<Song>()
    var cursor: Cursor? = null
    try {
        cursor = context.contentResolver.query(collection, projection, selection, null, sortOrder)
        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumIdCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            while (it.moveToNext()) {
                val id = it.getLong(idCol)
                val albumId = it.getLong(albumIdCol)
                val art = if (albumId > 0) ContentUris.withAppendedId(
                    Uri.parse("content://media/external/audio/albumart"), albumId
                ) else null
                result += Song(
                    id = id,
                    title = it.getString(titleCol) ?: "Unknown title",
                    artist = it.getString(artistCol) ?: "Unknown artist",
                    album = it.getString(albumCol) ?: "Unknown album",
                    duration = it.getLong(durationCol),
                    uri = ContentUris.withAppendedId(collection, id),
                    artUri = art
                )
            }
        }
    } catch (_: Exception) {
        return emptyList()
    }
    return result
}

private fun formatDuration(ms: Long): String {
    val totalSeconds = TimeUnit.MILLISECONDS.toSeconds(ms.coerceAtLeast(0L))
    return String.format("%d:%02d", totalSeconds / 60, totalSeconds % 60)
}
